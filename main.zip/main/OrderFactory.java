//Dan Soskey

public abstract class OrderFactory{
  public abstract Order makeOrder(int orderID);
}